"""FastAPI AI service package."""

