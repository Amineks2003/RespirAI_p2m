import mongoose from "mongoose";

const emergencyContactSchema = new mongoose.Schema(
  {
    name: { type: String, default: "" },
    phone: { type: String, default: "" },
  },
  { _id: false },
);

const doctorRiskHistoryEntrySchema = new mongoose.Schema(
  {
    score: { type: Number, required: true },
    confidence: { type: Number, default: null },
    sentAt: { type: Date, default: Date.now },
    source: { type: String, default: "manual-ai-rag" },
  },
  { _id: false },
);

const patientProfileSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, unique: true },
    patientCode: { type: String, required: true, unique: true, index: true },
    dob: { type: Date },
    gender: { type: String, default: "" },
    condition: { type: String, default: "" },
    bloodType: { type: String, default: "" },
    status: { type: String, enum: ["critical", "warning", "moderate", "stable"], default: "stable", index: true },
    doctor: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    admittedAt: { type: Date },
    latestUploadAt: { type: Date },
    latestUploadName: { type: String, default: "" },
    latestUploadData: { type: mongoose.Schema.Types.Mixed, default: null },
    latestAiInsights: { type: mongoose.Schema.Types.Mixed, default: null },
    latestDoctorSentResult: { type: mongoose.Schema.Types.Mixed, default: null },
    doctorRiskHistory: { type: [doctorRiskHistoryEntrySchema], default: [] },
    latestIntakeForm: { type: mongoose.Schema.Types.Mixed, default: null },
    emergencyContact: { type: emergencyContactSchema, default: () => ({}) },
  },
  { timestamps: true },
);

export const PatientProfile = mongoose.model("PatientProfile", patientProfileSchema);
