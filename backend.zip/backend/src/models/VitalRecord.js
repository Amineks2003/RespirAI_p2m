import mongoose from "mongoose";

const vitalRecordSchema = new mongoose.Schema(
  {
    patient: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    spo2: { type: Number, required: true },
    hr: { type: Number, required: true },
    rr: { type: Number, required: true },
    apneaLevel: { type: Number, default: 0 },
    coughEvents: { type: Number, default: 0 },
    wheezeDetected: { type: Boolean, default: false },
    source: { type: String, default: "wearable" },
    timestamp: { type: Date, default: Date.now, index: true },
  },
  { timestamps: true },
);

vitalRecordSchema.index({ patient: 1, timestamp: -1 });

export const VitalRecord = mongoose.model("VitalRecord", vitalRecordSchema);
